# FullStack Student database system
In this project I worked with several tools, I learned how to do API calls from React app to the DB, work with postman and MySQL database also I should mention ReactJS with MUI library for frontend and Java SpringBoot for backend. I also touched tools like Apache and Maven, a lot of knowledge in this project & starting to work on my portfolio and will put it there.
For FrontEnd I used Visual Studio Code IDE and for BackEnd Intellij idea.

![image](https://user-images.githubusercontent.com/81489104/175814670-403b56f3-4486-4af0-b359-e6da16964212.png)

![image](https://user-images.githubusercontent.com/81489104/175814660-a3f5b62e-9dc9-44ca-81bb-88b8453c34d5.png)

![image](https://user-images.githubusercontent.com/81489104/175783851-6b04c921-22d3-4767-a544-029a1639311e.png)

